within;
partial model KrskoPressureDevelopmentBase "Matched-boundary production pressure development experiment"
  // SPDX-License-Identifier: Apache-2.0
  // A published Doel input-model wall supplies a declared analogue, not Krško
  // construction. Existing assumed Krško volume fixes the equivalent radius.
  // See validation/krsko_pressure/candidate-config.json, frozen before scoring.
  parameter Boolean finitePhaseMode = false annotation(Evaluate=true);
  parameter Boolean wallMode = false annotation(Evaluate=true);
  parameter Integer wallSegments = 12;
  parameter Integer wallRadialCells = 8;
  parameter Real pressurizerPhaseRelaxationTimeS = .1;
  parameter Real pressurizerInterfacialConductanceWK = 0;
  parameter Real pressurizerVesselHeightM = 11.864;
  parameter Real pressurizerWallThicknessM = .1152;
  parameter Real pressurizerWallVolumetricHeatCapacityJm3K = 3.8775e6;
  parameter Real pressurizerWallConductivityWMK = 46.05;
  extends KrskoContinuousThermal(thermal(
    useFinitePhasePressurizer=finitePhaseMode,
    pressurizerIncludeWall=wallMode,
    pressurizerWallSegments=wallSegments,
    pressurizerWallRadialCells=wallRadialCells,
    pressurizerPhaseRelaxationTimeS=pressurizerPhaseRelaxationTimeS,
    pressurizerInterfacialConductanceWK=pressurizerInterfacialConductanceWK,
    pressurizerVesselHeightM=pressurizerVesselHeightM,
    pressurizerWallThicknessM=pressurizerWallThicknessM,
    pressurizerWallVolumetricHeatCapacityJm3K=pressurizerWallVolumetricHeatCapacityJm3K,
    pressurizerWallConductivityWMK=pressurizerWallConductivityWMK,
    pressurizerInitialWallTemperatureK=Water.saturationTemperature(initialPressurePa)));
  output Real pressurizerLiquidTemperatureC = thermal.pressurizerLiquidTemperatureC;
  output Real pressurizerVaporTemperatureC = thermal.pressurizerVaporTemperatureC;
  output Real pressurizerSteamPartialPressureMPa = thermal.pressurizerSteamPartialPressurePa/1e6;
  output Real pressurizerSaturationTemperatureC = thermal.pressurizerSaturationTemperatureC;
  output Real pressurizerWallEnergyMJ = thermal.pressurizerWallEnergyMJ;
  output Real pressurizerWallAmbientPowerW = thermal.pressurizerWallAmbientPowerMW*1e6;
  output Real pressurizerWallMinimumTemperatureK = thermal.pressurizerWallMinimumTemperatureK;
  output Real pressurizerWallMaximumTemperatureK = thermal.pressurizerWallMaximumTemperatureK;
  output Real pressureModelFinitePhase = if finitePhaseMode then 1 else 0;
  output Real pressureModelIncludesWall = if wallMode then 1 else 0;
  annotation(experiment(StartTime=0,StopTime=15,Interval=0.05,Tolerance=1e-11));
end KrskoPressureDevelopmentBase;

model KrskoPressureEquilibrium "Production equilibrium ablation with identical forcing"
  extends KrskoPressureDevelopmentBase(final finitePhaseMode=false,final wallMode=false,
    final wallSegments=12,final wallRadialCells=8);
end KrskoPressureEquilibrium;

model KrskoPressureCandidate "Finite phase inventories and declared analogue wall"
  extends KrskoPressureDevelopmentBase(final finitePhaseMode=true,final wallMode=true,
    final wallSegments=12,final wallRadialCells=8);
end KrskoPressureCandidate;

model KrskoPressureNoWall "Controlled wall-storage and condensation ablation"
  extends KrskoPressureDevelopmentBase(final finitePhaseMode=true,final wallMode=false,
    final wallSegments=12,final wallRadialCells=8);
end KrskoPressureNoWall;

model KrskoPressureRefinedWall "Same finite-phase physics with refined graded wall mesh"
  extends KrskoPressureDevelopmentBase(final finitePhaseMode=true,final wallMode=true,
    final wallSegments=24,final wallRadialCells=16);
end KrskoPressureRefinedWall;
